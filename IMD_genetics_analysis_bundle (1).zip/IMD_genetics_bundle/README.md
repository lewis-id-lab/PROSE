# IMD genetics thesis — analysis bundle

Prepared 16 October 2026, updated after the Job A full-text re-extraction. Self-contained: nothing here depends on the chat session.

## Read first

`phase3_decisions.md` is the pre-specification record for the four design decisions. Two of the four are fixed; two need a reply.

| file | what it is |
|---|---|
| `01_project_description.md` | the question, the design, the fixed baseline equation, the aims, the settled scope decisions |
| `02_current_status.md` | where every phase stands, what is verified, what blocks the genetic layer |
| `data/data_dictionary.csv` | column meanings for the derived files below |
| `data/codebook.csv` | the full extraction-form codebook (89 field definitions) |

## Baseline model (Aim 2) — ready to use

| file | rows | notes |
|---|---|---|
| `data/baseline_model_parameters.csv` | 8 | intercept plus 7 predictors: coefficient, odds ratio, and prevalence in cases, non-cases and overall |
| `data/baseline_validation_targets.csv` | 7 | what the synthetic cohort must reproduce, including the one quantity that is **not published** |

Coefficients are from the published equation and verified against the paper's Table 2 adjusted odds
ratios. **Keep them fixed.** The predictor joint distribution is not published and must be calibrated —
see section 6 of `02_current_status.md` for what independence costs.

## Evidence base (Aims 1 and 3)

| file | rows | notes |
|---|---|---|
| `data/panel_candidates.csv` | 22 | **Start panel selection here.** One row per variant reported by 3+ studies, with how many studies contribute an orientable estimate, how many contribute a complete genotype table, and the union — `studies_meta_analysable`. |
| `data/variant_evidence_summary.csv` | 237 | one row per rsID, all of them, with the same breakdown plus dbSNP gene, position and alleles |
| `data/jobB_status_table.csv` | 66 | per study x variant outcome of the Job B recovery pass, with the reason each unfilled cell could not be filled |
| `data/extraction_variants_round1.csv` | 1420 | the variant table, one row per study x variant x genetic model x subgroup, with dbSNP annotation and `orientation_flag` |
| `data/extraction_studies_round1.csv` | 81 | one row per included record, with `source_status` and the study-level design fields |
| `data/extraction_form_filled.xlsx` | — | the same two tables as the working extraction form, plus the codebook sheet |
| `data/extraction_merged.json` | 63 | the raw nested extraction, `study_id -> {study, variants}` |

## Quality control and round 2

| file | rows | notes |
|---|---|---|
| `data/round2_verification_list.csv` | 907 | rows ranked P1–P4 for human checking against source PDFs |
| `data/variant_orientation_qc.csv` | 1420 | per-row allele orientation against dbSNP |
| `data/pdf_source_audit.csv` | 81 | which document each extraction actually used, and whether it was the right one |
| `data/companion_records.csv` | 18 | records without a usable source and their likely duplicate full publications |
| `data/candidate_snp_seed_table.csv` | 25 | provisional panel with allele frequencies; 7 entries still PENDING, and the panel predates the extraction |

## TLR4 is usable, but only through genotype counts

rs4986790 has 9 studies reporting it and only 1 with a published estimate you can orient — but **5 with a
complete 2x3 genotype table**, from which an odds ratio can be computed under any model. rs4986791 has 4
such studies. Three of those papers (Ceesay 2016, Kalkanci 2020, Grube 2013) print counts and a p value
and no odds ratio at all.

Two things to handle when you pool them. Every one of these cohorts has **zero minor homozygotes in both
cases and controls**, so only a dominant or carrier model is estimable and a continuity correction is
needed; Tanpaibule 2020's rs4986790 is degenerate the other way (cases 33/0/0). And the TLR4 alleles in
Kalkanci 2020 and Grube 2013 were read from the papers' "896A>G" notation rather than from a genotype
column, so confirm orientation before use.

`data/jobB_status_table.csv` records, for each of the 66 cells chased, whether the gap was closed and if
not why — supplement not supplied, no allele printed anywhere, stated as a null with no numbers, or data
only inside a figure.

## Panel parameterisation inputs (new)

| file | rows | notes |
|---|---|---|
| `data/panel_allele_frequencies.csv` | 13 | gnomAD non-Finnish European and 1000 Genomes EUR allele frequencies for every panel variant, with the full dbSNP allele set and the position. Note rs1800896 is reported T/C by gnomAD where the literature writes A/G — the same variant on the opposite strand. |
| `data/haplotype_frequencies.csv` | 16 | two-locus haplotype frequencies in 1000G EUR for the PTX3 trio and the TLR4 pair, derived from the allele frequencies and D. **The phase sign is assumed** (minor alleles in coupling); D' near 1 fixes the magnitude, not the direction, so confirm against a source haplotype table before simulating. |
| `data/cohort_independence.csv` | 13 | per panel variant, the contributing studies and how many remain once same-group cohorts are collapsed |

## Four things to know before using the data

1. **No row has been verified against a source PDF by a human.** Every extracted row carries `second_checker = PENDING ROUND 2 VERIFICATION`. Treat round-1 values as provisional.
2. **Allele orientation is not settled.** 886 of 1420 rows name both alleles; 21 variants are reported on the opposite strand from dbSNP, including PTX3 rs2305619, and 9 rows name an allele dbSNP does not record at that position. Filter on `orientation_flag` before pooling, and remember a flipped risk allele inverts the modelled effect.
3. **33 rows were transcribed by the extracting agent rather than produced by a model pass**, after its call budget ran out. They carry `extraction_method = agent_read_not_model_extracted` and are flagged P1 in the round-2 list. Check them first.
4. **Several studies report the same patients.** The Spanish registry series and the Jena AML cohorts are not independent. Adjudicate overlap before any pooled estimate; `extraction_studies_round1.csv` carries an `overlapping_cohort_suspected` flag that has not yet been checked.

## Reading the data in R

```r
library(data.table)
base  <- fread("data/baseline_model_parameters.csv")
targ  <- fread("data/baseline_validation_targets.csv")
ev    <- fread("data/variant_evidence_summary.csv")
vars  <- fread("data/extraction_variants_round1.csv")
studs <- fread("data/extraction_studies_round1.csv")

# fixed clinical linear predictor
b0    <- base[term == "(Intercept)", coefficient]
coefs <- base[term != "(Intercept)", setNames(coefficient, term)]

# candidate panel: variants with independent replication and usable estimates
panel <- fread("data/panel_candidates.csv")
panel[studies_meta_analysable >= 3][order(-studies_meta_analysable)]

# rows you can actually pool: a usable estimate, or a complete genotype table
vars[meta_analysable == "yes"]

# rows produced by a model pass only, excluding agent-transcribed ones
vars[extraction_method != "agent_read_not_model_extracted"]

# rows safe to pool on orientation grounds
vars[orientation_flag %in% c("fwd_ok", "fwd_ok_ambiguous") &
     effect_estimate != "" & ci_lower != "" & ci_upper != ""]
```

Note that `fwd_ok_ambiguous` means an A/T or C/G variant whose orientation cannot be settled from the
allele letters alone — it is not a clean pass, and those rows need the source's own strand statement or an
allele-frequency comparison.
