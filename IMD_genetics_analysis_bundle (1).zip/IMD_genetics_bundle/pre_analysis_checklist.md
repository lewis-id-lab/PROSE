# What has to happen before the R analysis

Checklist as at 16 October 2026. Items marked **you** need your judgement; items marked *agent* I can do on request.

---

## A. Start now — nothing blocks these

- ☐ **A1. Code the baseline equation with a verification harness.** Fixed coefficients, no fitting. Inputs are in `data/baseline_model_parameters.csv` and `data/baseline_validation_targets.csv`, both verified against the Stanzani paper.
- ☐ **A2. Fit the predictor correlation structure.** Independence gives 2.27% prevalence and aROC 0.775 against the published 3.3% and 0.85. A single exchangeable latent correlation of 0.30 hits both global targets but misses the per-predictor case-group prevalences, so a clinically constrained matrix fitted to all 16 published targets is needed. Pre-specify it and report it as a model assumption.
- ☐ **A3. Build the decision-curve machinery on the baseline alone**, so net benefit at the 5% and 20% thresholds is working before any genetic term exists.
- ☐ **A4 (you). Email Bologna** for three 2x2 cross-tabulations — chemotherapy x neutropenia, neutropenia x lymphopenia, malignancy status x chemotherapy — and the distribution of admissions per patient. This converts A2 from an assumption into data, and the request is small.

## B. Four decisions only you can make (the Phase 3 gate)

- ☐ **B1. Recipient or donor genotype** as the primary exposure, with the other as a sensitivity analysis.
- ☐ **B2. Haplotype or single tag SNP** for PTX3 and for TLR4. The evidence: in 1000 Genomes EUR, rs2305619 and rs1840680 are at r² = 0.996 and are interchangeable; rs3816527 sits at r² ≈ 0.79 with both and contributes about 6% of chromosomes that differ. The trio collapses to two haplotypes, h2 at roughly 0.40–0.46 and h1 at roughly 0.54.
- ☐ **B3. Final panel composition** — see section D.
- ☐ **B4. The minimum clinically important difference in net benefit**, written down *before* any result exists. Without this the headline finding cannot be falsified.

## C. Verify the panel rows — 299 rows, not the whole table

The full table carries 2008 rows and a round-2 list of 1,380. **You do not need to verify all of that to run Aim 3.** Only the rows feeding the panel matter, and there are 299. `data/panel_verification_worklist.csv` lists them, sorted so the consequential ones come first.

| what it needs | rows | distinct study x variant decisions |
|---|---|---|
| **strand flip — must be corrected before pooling** | 38 | 10 |
| C/G variant, strand not resolvable from alleles | 25 | 7 |
| allele pair incomplete | 9 | — |
| other specific resolution (derived, transcribed, duplicate, flagged) | 21 | — |
| routine confirmation against the source table | ~206 | — |

- ☐ **C1. The 10 strand-flip cells.** Each reports alleles that are the complement of the pair segregating in Europeans, so the risk allele is inverted: rs16910526 in S035, S056, S070 and S080; rs1800896 in S003 and S061; rs2069705 in S072 and S080; rs5743810 in S061 and S080. CLEC7A rs16910526 is the striking one — it is widely reported as a T allele (Y238X) where dbSNP records A/C and gnomAD non-Finnish European gives A 0.923 / C 0.077. Left uncorrected these flip the sign of the effect.
- ☐ **C2. The seven rs7309123 cells.** rs7309123 is C/G, a true palindrome, so no amount of allele comparison resolves it — each study needs its own strand statement, assay reference, or an allele-frequency comparison against gnomAD NFE (C 0.574, G 0.426, which is close to 50:50 and therefore weak evidence). It is the second-most-reported panel variant, in eight studies.
- ☐ **C3. The 33 rows flagged derived, transcribed, duplicated or ambiguous** by the extractor.
- ☐ **C4. The routine remainder**, or a 10% sample of it with per-field agreement reported, if time is short.

## D. Settle the panel

- ☐ **D1.** 13 variants reach three or more *independent cohorts* once same-group series are collapsed; **six reach four or more** — rs16910526 (7), rs2305619 (7), rs7309123 (6), rs3816527 (6), rs4986790 (5), rs4986791 (4). `data/cohort_independence.csv` has the adjustment per variant.
- ☐ **D2. Drop TLR9 rs352140** — three studies report it, one is usable.
- ☐ **D3. Decide on Herrero-Sanchez 2018.** Its supplementary rows use *Candida*/*Aspergillus* detection or colonisation as the endpoint, not proven or probable invasive mould disease. It contributes to rs16910526, rs2305619, rs3816527 and rs1840680, so excluding it costs those variants a cohort each.
- ☐ **D4. Decide the TLR4 pooling model.** Both TLR4 SNPs are usable only through genotype counts, and every contributing cohort has zero minor homozygotes in cases and controls, so only a dominant or carrier model is estimable and a continuity correction is needed.

## E. Parameterisation inputs — done, but check two things

- ☑ Allele frequencies for all 13 panel variants, gnomAD non-Finnish European and 1000G EUR — `data/panel_allele_frequencies.csv`.
- ☑ Two-locus haplotype frequencies for the PTX3 trio and the TLR4 pair — `data/haplotype_frequencies.csv`.
- ☐ **E1. Confirm the haplotype phase sign.** The derivation assumes the minor alleles are in coupling. D' near 1 fixes the magnitude of D, not its direction; check against a published haplotype table before simulating.
- ☐ **E2. Note rs1800896.** gnomAD reports it T/C where the literature universally writes A/G — the same variant on the opposite strand. It is the most-cited IL10 promoter SNP in this field and a natural place for an orientation error to enter.

## F. Not blocking, finish at write-up

- ☐ F1. Skonieczna 2017's supplement is still missing; it reports Fisher p values with no odds ratios, so write it into the limitations rather than chase it.
- ☐ F2. The date the PubMed searches were run is still unrecorded (Embase was 8 October 2026).
- ☐ F3. The automated screening decision file for all 831 records has not been assembled — this is a PRISMA audit-trail item.
- ☐ F4. Confirm with Bologna whether an Italian thesis title is required and whether there is a character limit.

---

## Corrections made while compiling this list

Two bugs in my own orientation flag, both now fixed, and both changed the answer.

The flag tested reported alleles against the **full dbSNP allele set**. For a multi-allelic record such as rs16910526 (A/C/G/T) every pair's complement is also a subset, so six panel variants were wrongly marked ambiguous. Testing instead against the alleles actually segregating in Europeans resolves all six — none of them is palindromic.

Worse, the flag treated a true palindrome as unambiguous: for a C/G variant the complement *equals* the reported pair, and the condition excluded exactly the case it should have caught. rs7309123 — eight studies, the second-most-reported panel variant — was marked clean when it is the one variant whose strand genuinely cannot be settled from alleles.

The corrected counts across all 2008 rows: fwd_ok 701, strand_flip 188, palindromic_unresolvable 130, single_allele_only 234, no_alleles 444, mismatch 4, no valid rsID 306. Previously I reported 85 strand flips and 332 ambiguous; the real figures are 188 flips and 130 genuinely unresolvable.
