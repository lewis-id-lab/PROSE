# Genetic augmentation of a validated clinical risk model for invasive mould disease in haematological malignancy

**A simulation study of incremental value.**

Project description for the analyst. Written 16 October 2026.

---

## 1. The question

A validated clinical risk score already predicts 60-day invasive mould disease (IMD) in haematological
inpatients with an aROC of 0.85. Candidate host genetic variants — PTX3, dectin-1/CLEC7A, DC-SIGN/CD209,
TLR4 and others — are repeatedly reported as associated with invasive aspergillosis. The thesis asks
whether adding them to the clinical score would change what a clinician does.

It is framed as a value-of-information question rather than a prediction-improvement exercise:

> Under what combinations of effect size, risk-allele frequency and linkage structure would host genetic
> information change clinical decisions for invasive mould disease in haematological patients — and is the
> published evidence anywhere near those combinations?

This framing matters because it makes a negative result publishable and the thesis falsifiable. If the
answer is that no realistic genetic architecture moves the decision curve, that is a finding, not a
failure.

## 2. Why the predecessor thesis has to be redone rather than extended

The unfinished predecessor simulated three PTX3 SNPs — rs2305619, rs3816527 and rs1840680 — as independent
multiplicative risks. In 1000 Genomes EUR they are in strong linkage disequilibrium: rs2305619–rs1840680
r² = 0.996, rs2305619–rs3816527 r² = 0.787, rs3816527–rs1840680 r² = 0.790, with D′ = 1 throughout. They
are tags for the same h1/h2 haplotype. Simulating them independently triple-counts one signal, which is
where the reported rs1840680 homozygote odds ratio of 15.2 and much of the reported net reclassification
improvement of 22.5% come from.

This is corroborated externally: Feys et al. (*J Infect Dis* 2026) measured rs2305619–rs3816527 at D′ = 1,
r² = 0.87 and analysed the haplotype rather than the separate SNPs.

The predecessor also used dbSNP global minor allele frequency (rs2305619 = 0.36) where the cohort is
European; gnomAD non-Finnish European gives 0.482, which shifts the homozygote class from 13% to 21% of the
cohort.

## 3. Design

**Baseline model — kept fixed, never refitted.** Stanzani et al., *J Infect* 2019;78:484–490. A Bologna
cohort of 4,127 admissions in 1,944 patients, 2007–2016, with 133 EORTC/MSG proven or probable IMD events
(3.3%).

```
logit(p) = -5.45
         + 0.68 * uncontrolled malignancy
         + 0.79 * high-risk chemotherapy
         + 0.80 * high-dose corticosteroids
         + 0.89 * severe lymphopenia
         + 1.14 * CMV reactivation or disease
         + 1.52 * prolonged neutropenia
         + 1.64 * previous mould disease within 90 days
```

Exponentiating each coefficient reproduces the adjusted odds ratios in the paper's Table 2 to two decimal
places, so both the coefficients and the intercept are verified against source. Only genetic terms are
fitted; the clinical block is held at its published values.

**Primary endpoint: decision-curve net benefit**, evaluated across thresholds 1–30% and reported at 5% and
20%. Net reclassification improvement is retained only as a tertiary comparator, because NRI is the metric
that produced the predecessor's headline number and is well known to be unstable and to reward
miscalibration.

**Genotypes are simulated LD-aware at patient level.** PTX3 and TLR4 are collapsed to haplotypes. Loci in
different genes are treated as independent, which is correct between genes — the predecessor's error was
treating linked SNPs *within* a gene as independent.

**Allele frequencies** come from gnomAD v4 non-Finnish European as primary, 1000 Genomes EUR as
cross-check, with the risk allele pinned by nucleotide rather than by "minor allele".

## 4. Aims

| Aim | Content |
|---|---|
| 1 | Systematic review and evidence synthesis of host germline variants and IMD in haematological malignancy |
| 2 | Reproduce the Stanzani baseline in a synthetic cohort and verify against its published performance |
| 3a | LD-aware multi-locus genetic risk score added to the fixed clinical model |
| 3b | Neutropenia-stratified falsification test |
| 4 | Genetic-architecture requirements sweep: 1–20 loci x OR 1.1–3.0 x risk-allele frequency 0.05–0.50 |
| 5 | Translation — what would have to be true for genotyping to be worth doing |

**On Aim 3b.** Feys et al. found that PTX3 and CLEC7A variants do *not* predispose to influenza- or
COVID-associated pulmonary aspergillosis, and explain this by inflammatory levelling: severe viral
pneumonia induces PTX3 as an acute-phase protein, so genotype-determined baseline differences are swamped.
Neutropenia is used as a **proxy for the non-inflamed host** on that logic. It is not an assertion that the
effects are neutrophil-dependent, and the chapter should not say that it is.

## 5. Scope decisions already settled

1. **Outcome is all proven/probable invasive mould disease**, not aspergillosis alone. Risk factors overlap almost completely in haematological patients and this keeps all 133 events. *Aspergillus*-specific estimates are handled as a pre-specified pathogen-specificity scenario in the Aim 4 surface.
2. **Virus-associated pulmonary aspergillosis is excluded in every form** — IAPA, CAPA and combined VAPA. Different pathology (hyperinflammatory ARDS, virus-driven epithelial damage, typically non-neutropenic and corticosteroid-immunosuppressed), and the Bologna cohort is entirely pre-pandemic. Non-viral ICU aspergillosis remains eligible as indirect evidence. The consequent limitation is that the baseline model is pre-pandemic and its calibration today is unknown.
3. Second baseline risk model, somatic myeloid NGS variants, hypothesis-free discovery and non-European ancestry extension are all explicitly out of scope.

## 6. State of the evidence base

No human host genome-wide association study of invasive aspergillosis exists, and no genetic or polygenic
risk score for IA or IMD has been published. The evidence is entirely candidate-gene.

81 records were included after screening; 63 have a usable source document and have been extracted,
yielding 1420 variant rows across 237 distinct rsIDs. The number that governs what can be meta-analysed is
how many independent studies report a variant, and only 22 clear three:

| rsID | gene (dbSNP) | studies | rows | with genotype counts | poolable rows |
|---|---|---|---|---|---|
| rs16910526 | CLEC7A | 12 | 37 | 3 | 11 |
| rs7309123 | CLEC7A | 10 | 34 | 5 | 25 |
| rs2305619 | PTX3 | 9 | 54 | 32 | 45 |
| rs4986790 | TLR4 | 9 | 14 | 7 | 2 |
| rs4986791 | TLR4 | 9 | 14 | 6 | 1 |
| rs3816527 | PTX3 | 7 | 48 | 31 | 39 |
| rs7248637 | CD209 | 6 | 15 | 4 | 12 |
| rs4804800 | CD209 | 5 | 11 | 5 | 10 |
| rs5743708 | TLR2 | 5 | 11 | 4 | 3 |
| rs1840680 | PTX3 | 4 | 37 | 30 | 36 |
| rs11465384 | CD209 | 4 | 10 | 4 | 4 |
| rs1800896 | IL10 | 3 | 13 | 2 | 11 |
| rs3901533 | CLEC7A | 3 | 9 | 4 | 8 |
| rs2069705 | IFNG | 3 | 8 | 2 | 6 |
| rs352140 | TLR9 | 3 | 8 | 2 | 0 |
| rs3775291 | TLR3 | 3 | 8 | 2 | 1 |
| rs7252229 | CD209 | 3 | 6 | 4 | 4 |
| rs3921 | ART3 | 3 | 5 | 1 | 2 |
| rs5743810 | TLR6 | 3 | 5 | 3 | 3 |
| rs1554013 | ART3 | 3 | 4 | 1 | 2 |
| rs4257674 | ART3 | 3 | 4 | 1 | 2 |
| rs5743611 | TLR1 | 3 | 4 | 3 | 1 |

That list is the realistic ceiling on the SNP panel Aim 3 can parameterise from published data.

## 7. Open design decisions (the Phase 3 gate)

None of these should be settled by whoever happens to be writing the script:

1. Recipient or donor genotype as the primary exposure, with the other as a sensitivity analysis.
2. Haplotype or single tag SNP for PTX3 and for TLR4.
3. Final panel composition, derived from the extracted table rather than from the provisional list.
4. The minimum clinically important difference in net benefit — **fixed before any results exist**, otherwise the headline finding cannot be falsified.
5. How the per-patient genetic term enters a per-admission model, given 4,127 admissions in 1,944 patients.
